import { BOARD_SYMBOLS, PUNCTUATION_SYMBOLS, type BoardSymbol } from "./keys";
import { requiredBoardSymbols } from "./target";
import { trapLooksLikeTarget } from "./visualTraps";
import { reserveAnswerCopies } from "./answerCopies";

export const BOARD_SIZE = 81;
export const WORD_BOARD_SIDE = 8;
const TENSE_SYMBOLS = new Set<string>(["ㄲ", "ㄸ", "ㅃ", "ㅆ", "ㅉ"]);
export const TARGET_SYMBOL_BUFFER = 1.5;
export const MIRROR_TRAP_CHANCE = 0.2;
export type GlyphTransform = "flip-x" | "flip-y" | "rotate-90" | "rotate-180" | "rotate-270";

/** Only transformations that visibly change the glyph are offered as traps. */
const TRAP_TRANSFORMS: Readonly<Partial<Record<BoardSymbol, readonly GlyphTransform[]>>> = {
  "ㄱ": ["flip-x", "flip-y"], "ㄲ": ["flip-x", "flip-y"], "ㄴ": ["flip-x", "flip-y"],
  "ㄷ": ["flip-x", "rotate-90"], "ㄸ": ["flip-x", "rotate-90"],
  "ㄹ": ["flip-x", "flip-y", "rotate-90"],
  "ㅂ": ["rotate-90"], "ㅃ": ["rotate-90"],
  "ㅅ": ["flip-y", "rotate-90"], "ㅆ": ["flip-y", "rotate-90"],
  "ㅈ": ["flip-y", "rotate-90"], "ㅉ": ["flip-y", "rotate-90"],
  "ㅊ": ["flip-y", "rotate-90"], "ㅋ": ["flip-x", "flip-y"],
  "ㅌ": ["rotate-90"], "ㅍ": ["rotate-90"], "ㅎ": ["flip-y", "rotate-90"],
};

export function trapTransformsFor(symbol: BoardSymbol): readonly GlyphTransform[] {
  if (!TRAP_TRANSFORMS[symbol]) return [];
  if (symbol === "ㄹ") return ["flip-x", "rotate-90"];
  if (symbol === "ㅍ") return ["rotate-90"];
  return ["rotate-90", "rotate-180", "rotate-270"];
}

export function trapTransformFor(symbol: BoardSymbol, rng: () => number = Math.random): GlyphTransform | undefined {
  const transforms = trapTransformsFor(symbol);
  return transforms[Math.floor(rng() * transforms.length)];
}

export interface LetterTile {
  id: number;
  symbol: BoardSymbol;
  /** True when this copy was reserved to make the target solvable. */
  required: boolean;
  /** Punctuation-free word boards may show a visibly transformed spare consonant. */
  transform?: GlyphTransform;
  shape?: "♥" | "★" | "," | "╱" | "╲";
}

export const MIRROR_TRAP_TOKEN = "×";

export function inputValueForTile(tile: Pick<LetterTile, "symbol" | "transform" | "shape">): BoardSymbol | typeof MIRROR_TRAP_TOKEN {
  return tile.transform || tile.shape ? MIRROR_TRAP_TOKEN : tile.symbol;
}

export type SymbolWeights = Readonly<Partial<Record<BoardSymbol, number>>>;

/** Common Korean letters receive more of the board's spare positions. */
export const DEFAULT_SYMBOL_WEIGHTS: SymbolWeights = {
  "ㄱ": 8, "ㄲ": 2, "ㄴ": 12, "ㄷ": 6, "ㄸ": 2, "ㄹ": 9, "ㅁ": 7,
  "ㅂ": 6, "ㅃ": 2, "ㅅ": 10, "ㅆ": 3, "ㅇ": 14, "ㅈ": 6, "ㅉ": 2,
  "ㅊ": 4, "ㅋ": 3, "ㅌ": 3, "ㅍ": 3, "ㅎ": 7,
  "ㅣ": 12, "ㆍ": 14, "ㅡ": 9,
  ".": 1, "!": 1, "?": 1,
};

function weightedPick(rng: () => number, weights: SymbolWeights, symbols: readonly BoardSymbol[]): BoardSymbol {
  const entries = symbols.map((symbol) => [symbol, Math.max(0, weights[symbol] ?? 2)] as const);
  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  let cursor = rng() * total;
  for (const [symbol, weight] of entries) {
    cursor -= weight;
    if (cursor <= 0) return symbol;
  }
  return symbols[symbols.length - 1]!;
}

function shuffle<T>(values: T[], rng: () => number): T[] {
  for (let index = values.length - 1; index > 0; index--) {
    const other = Math.floor(rng() * (index + 1));
    [values[index], values[other]] = [values[other]!, values[index]!];
  }
  return values;
}

export function createLetterBoard(
  target: string,
  rng: () => number = Math.random,
  weights: SymbolWeights = DEFAULT_SYMBOL_WEIGHTS,
  size = BOARD_SIZE,
  symbols: readonly BoardSymbol[] = BOARD_SYMBOLS,
  extraAnswerCopies?: number,
): LetterTile[] {
  const targetSymbols = requiredBoardSymbols(target);
  const punctuationFree = !targetSymbols.some((symbol) =>
    (PUNCTUATION_SYMBOLS as readonly string[]).includes(symbol),
  );
  const dealSymbols = punctuationFree
    ? symbols.filter((symbol) => !(PUNCTUATION_SYMBOLS as readonly string[]).includes(symbol))
    : symbols;
  const bufferedCount = Math.ceil(targetSymbols.length * TARGET_SYMBOL_BUFFER);
  const required = extraAnswerCopies === undefined ? [...targetSymbols] : reserveAnswerCopies(targetSymbols, extraAnswerCopies, size);
  for (let index = required.length; extraAnswerCopies === undefined && index < bufferedCount; index += 1) {
    required.push(targetSymbols[index % targetSymbols.length]!);
  }
  if (required.length > size) {
    throw new RangeError(`Target needs ${required.length} buffered board symbols; maximum is ${size}.`);
  }

  const tiles: LetterTile[] = required.map((symbol, id) => ({ id, symbol, required: true }));
  // A capped answer must not sneak back in through the random filler pool.
  const fillerSymbols = extraAnswerCopies === undefined ? dealSymbols : dealSymbols.filter(symbol => !targetSymbols.includes(symbol));
  while (tiles.length < size) {
    if (!fillerSymbols.length) {
      tiles.push({ id: tiles.length, symbol: "ㆍ", shape: "★", required: false });
      continue;
    }
    const symbol = weightedPick(rng, weights, fillerSymbols);
    let transform = punctuationFree && rng() < MIRROR_TRAP_CHANCE ? trapTransformFor(symbol, rng) : undefined;
    if (transform && trapLooksLikeTarget(symbol, transform, targetSymbols)) transform = undefined;
    tiles.push({ id: tiles.length, symbol, required: false, ...(transform ? { transform } : {}) });
  }
  return shuffle(tiles, rng);
}

/** Word uses basic consonant taps, including repeated taps for tense consonants. */
export function createWordBoard(target: string, rng: () => number = Math.random, extraAnswerCopies?: number): LetterTile[] {
  const board = createLetterBoard(target, rng, DEFAULT_SYMBOL_WEIGHTS, WORD_BOARD_SIDE ** 2,
    BOARD_SYMBOLS.filter((symbol) => !TENSE_SYMBOLS.has(symbol)), extraAnswerCopies);
  // Reuse existing trap slots first; never replace reserved answers or their spares.
  const spare = board.filter(tile => !tile.required);
  const slots = [...spare.filter(tile => tile.transform), ...spare.filter(tile => !tile.transform)];
  const shapes = shuffle<NonNullable<LetterTile["shape"]>>(["♥", "★", ",", "╱", "╲"], rng);
  shapes.forEach((shape, index) => {
    const tile = slots[index];
    if (!tile) return;
    tile.shape = shape;
    tile.symbol = shape === "╱" || shape === "╲" ? "ㅣ" : "ㆍ";
    delete tile.transform;
  });
  return board;
}
