import { el } from "../dom";
import { APP_CONFIG } from "../../config/app";
import { RESULT_CARD_MS, tutorialReward } from "../../content/timedStages";
import { ClipSound } from "../clipSound";

/**
 * The beat between the last move and the results panel.
 *
 * A run used to end straight into a panel of numbers, which reads as being
 * marked rather than as having finished something. It ends in two beats now.
 * First the board dims and says what happened and what it was worth, in one
 * big number, for a few seconds. Then a word lands and a character dances,
 * holding on the last frame until the player taps — so the moment ends when
 * they are done with it rather than on a timer.
 *
 * The clips are optional. With `CHEER_CLIPS` empty the word carries the moment
 * on its own and holds for `WORD_ONLY_MS`, so the game never waits on an asset
 * to look right. See docs/CONTENT.md for what to hand over.
 */
interface Clip {
  /** The picture, muted. */
  video: string;
  /** H.264 fallback used by iPhone/iPad Safari. */
  iosVideo?: string;
  /** Its soundtrack, the same length. Optional. */
  sound?: string;
  layout: "compact" | "standard" | "large" | "hero";
}

const CLIP_TIERS: readonly { at: number; clips: readonly Clip[] }[] = APP_CONFIG.assets.celebrations.map((tier) => ({
  at: tier.at,
  clips: tier.clips.map((clip) => ({ ...clip, layout: tier.layout })),
}));

const prefersIosVideo = (): boolean => {
  if (typeof navigator === "undefined") return false;
  return /iPhone|iPad|iPod/i.test(navigator.userAgent)
    || (/Macintosh/i.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
};

const videoFor = (clip: Clip): string => prefersIosVideo() && clip.iosVideo ? clip.iosVideo : clip.video;

export function poolFor(score: number): readonly Clip[] {
  return CLIP_TIERS.find((tier) => score >= tier.at)?.clips ?? CLIP_TIERS[CLIP_TIERS.length - 1]!.clips;
}

export function randomClipFor(score: number, random: () => number = Math.random): Clip | null {
  const pool = poolFor(score);
  return pool.length ? pool[Math.floor(random() * pool.length)]! : null;
}

export function failureClip(): Clip {
  return APP_CONFIG.assets.failureCelebration;
}

/**
 * Four milliseconds of nothing, as a file.
 *
 * iOS will not let a page start an `<audio>` element from a timer — and the
 * clip's soundtrack starts from one, four seconds after the run ended, long
 * past any touch. What it will allow is an element that has already been
 * played once inside a real touch: after that the element stays permitted for
 * the rest of the session, swapping `src` included. So the first touch
 * anywhere plays this, which is silence at 8kHz and inaudible by
 * construction, and the soundtrack is allowed when its turn comes.
 */
const SILENCE =
  "data:audio/wav;base64,UklGRkQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YSAAAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgA==";

/** How long the score card holds before the dance. */
const CARD_MS = RESULT_CARD_MS;

/** How long the word holds when there is no clip. Long enough to read. */
const WORD_ONLY_MS = 1400;

/**
 * The longest a clip is allowed to run before the tap prompt appears anyway.
 *
 * A video that fails to decode, or one the browser silently refuses to start,
 * would otherwise leave the player looking at a dimmed board with nothing to
 * tap. The clip normally reaches its own end well before this.
 */
const CLIP_CAP_MS = 15000;

/**
 * Plays a file from its first frame, whether or not it is the one already
 * loaded.
 *
 * Rewinding is one of two different things depending on that: a new `src`
 * starts at zero on its own, while the same file over again has to be told.
 * The old code did both at once — assign, then set `currentTime` — and Safari
 * throws on a seek into a file it has not read the header of yet, which took
 * the whole flourish down with it.
 */
function start(media: HTMLMediaElement, src: string): Promise<void> {
  load(media, src);
  return media.play();
}

function load(media: HTMLMediaElement, src: string): void {
  const url = new URL(src, location.href).href;
  if (media.src === url) media.currentTime = 0;
  else media.src = url;
}

export class Cheer {
  private readonly root = el<HTMLDivElement>("cheer");
  private readonly word = el<HTMLDivElement>("cheer-word");
  private readonly clip = el<HTMLVideoElement>("cheer-clip");
  private readonly card = el<HTMLDivElement>("cheer-card");
  private readonly headline = el<HTMLParagraphElement>("cheer-headline");
  private readonly scoreEl = el<HTMLParagraphElement>("cheer-score");
  private readonly sound = el<HTMLAudioElement>("cheer-sound");
  private readonly soundtrack = new ClipSound();
  private readonly soundRetry = document.createElement("button");
  private soundRevision = 0;
  private timer: number | undefined;
  private soundOn = true;
  /** Whether the sound element has been played inside a touch yet. */
  private primed = false;
  /** Guards against the clip ending and the cap firing for the same play. */
  private done: (() => void) | undefined;
  private pick: Clip | null = null;
  private automatic = false;

  constructor() {
    this.soundRetry.type = "button";
    this.soundRetry.className = "cheer-sound-retry hidden";
    this.soundRetry.textContent = "Tap for sound";
    this.root.append(this.soundRetry);
    this.soundRetry.addEventListener("click", event => {
      event.stopPropagation(); this.soundtrack.unlock();
      if (this.pick && this.done) void this.playSound(this.pick);
    });
    // The clip stops on its own last frame; the player decides when to leave it.
    this.clip.addEventListener("ended", () => this.hold());
    this.clip.addEventListener("error", () => { if (this.card.classList.contains("hidden")) this.hold(); });
    this.root.addEventListener("pointerdown", (event) => {
      if ((event.target as Element).closest(".cheer-sound-retry")) return;
      event.preventDefault(); event.stopPropagation();
      if (this.root.classList.contains("cheer-hold")) this.finish();
    });
  }

  /**
   * Lets the soundtrack play later, by playing silence now.
   *
   * Called from the first touch anywhere and a no-op after it works. A
   * refusal leaves it unprimed so the next touch tries again; the picture
   * plays either way, muted, which every browser allows unprompted.
   *
   * Note this cannot beat the iPhone's hardware silent switch: that mutes
   * `<audio>` and `<video>` whatever the page does. Only a native audio
   * session set to playback overrides it, which is the Capacitor shell's job,
   * not the web layer's.
   */
  unlock(): void {
    this.soundtrack.unlock();
    if (this.done) return;
    if (this.primed) return;
    this.primed = true;
    this.sound.src = SILENCE;
    const started = this.sound.play() as Promise<void> | undefined;
    void started
      ?.then(() => { if (!this.done && this.sound.src === SILENCE) this.sound.pause(); })
      .catch(() => {
        this.primed = false;
      });
  }

  /**
   * Plays the flourish, then calls `then` — once, whichever way it ends.
   *
   * `headline` is what ended the run and `score` what it was worth; they hold
   * the screen on their own before the dance begins.
   */
  play(headline: string, score: number, text: string, then: () => void, tierScore = score): void {
    this.begin(headline, score, text, then, randomClipFor(tierScore));
  }

  playFailure(headline: string, text: string, then: () => void): void {
    this.begin(headline, 0, text, then, failureClip());
  }

  /** Unscored tutorial milestone; wait for a tap after the dance. */
  playTutorial(then: () => void, side = 2): void {
    const reward = tutorialReward(side);
    this.begin("", 0, reward.text, then, randomClipFor(reward.at));
    this.dance();
  }

  /** A short intermission, not a scored result; continue automatically after the dance. */
  playBonus(then: () => void): void {
    this.begin("", 0, "BONUS!", then, randomClipFor(1500));
    this.automatic = true;
    this.dance();
  }

  private begin(headline: string, score: number, text: string, then: () => void, pick: Clip | null): void {
    this.hush();
    this.automatic = false;
    this.word.textContent = text;
    this.headline.textContent = headline;
    this.scoreEl.textContent = score.toLocaleString();
    this.done = then;

    this.root.classList.remove("hidden", "cheer-hold", "cheer-run", "cheer-layout-compact", "cheer-layout-standard", "cheer-layout-large", "cheer-layout-hero");
    this.card.classList.remove("hidden");

    this.pick = pick;
    if (this.pick) {
      this.root.classList.add(`cheer-layout-${this.pick.layout}`);
      load(this.clip, videoFor(this.pick));
      if (this.pick.sound) { load(this.sound, this.pick.sound); this.soundtrack.prepare(this.pick.sound); }
    }

    window.clearTimeout(this.timer);
    this.timer = window.setTimeout(() => this.dance(), CARD_MS);
  }

  /** Second beat: the word and the dance. */
  private dance(): void {
    if (!this.done) return;
    this.card.classList.add("hidden");
    // Restarting the animation needs the class off for a frame, or a second
    // run in the same session shows the end state and never moves.
    this.root.classList.remove("cheer-run");
    void this.root.offsetWidth;
    this.root.classList.add("cheer-run");

    const pick = this.pick;

    window.clearTimeout(this.timer);
    if (!pick) {
      this.clip.classList.add("hidden");
      this.timer = window.setTimeout(() => this.hold(), WORD_ONLY_MS);
      return;
    }

    this.clip.classList.remove("hidden");
    // Muted and inline, so this is allowed without a gesture; a refusal still
    // lands on `finish` rather than stalling the run.
    const revision = this.soundRevision;
    void start(this.clip, videoFor(pick)).then(() => {
      if (revision === this.soundRevision && this.done) void this.playSound(pick);
    }).catch(() => this.hold());

    this.timer = window.setTimeout(() => this.hold(), CLIP_CAP_MS);
  }

  /**
   * The clip has played out. It stays on its last frame — a paused video keeps
   * showing it — and the screen starts taking taps.
   */
  private hold(): void {
    if (!this.done || !this.card.classList.contains("hidden")) return;
    if (this.automatic) { this.finish(); return; }
    window.clearTimeout(this.timer);
    this.clip.pause();
    this.sound.pause();
    this.soundtrack.stop(); this.soundRevision++;
    this.soundRetry.classList.add("hidden");
    this.root.classList.add("cheer-hold");
  }

  /** Takes it off screen at once — for a run left before it finished. */
  stop(): void {
    window.clearTimeout(this.timer);
    this.done = undefined;
    this.pick = null;
    this.hush();
    this.root.classList.add("hidden");
    this.root.classList.remove("cheer-hold");
    this.card.classList.remove("hidden");
  }

  /** Follows the sound switch in settings; the picture always plays. */
  setSound(on: boolean): void {
    this.soundOn = on;
    if (!on) { this.sound.pause(); this.soundtrack.stop(); this.soundRevision++; this.soundRetry.classList.add("hidden"); }
  }

  private async playSound(pick: Clip): Promise<void> {
    if (!this.soundOn || !pick.sound || !this.done || this.root.classList.contains("cheer-hold")) return;
    const revision = ++this.soundRevision;
    this.soundRetry.classList.add("hidden"); this.sound.pause();
    try {
      await this.soundtrack.play(pick.sound, () => this.clip.currentTime);
    } catch {
      if (revision !== this.soundRevision || !this.done || !this.soundOn) return;
      try {
        load(this.sound, pick.sound);
        if (this.sound.readyState >= 1) this.sound.currentTime = this.clip.currentTime;
        await this.sound.play();
        if (revision !== this.soundRevision) this.sound.pause();
      } catch {
        if (revision === this.soundRevision && this.soundOn) this.soundRetry.classList.remove("hidden");
      }
    }
  }

  private hush(): void {
    this.soundRevision++; this.soundtrack.stop(); this.soundRetry.classList.add("hidden");
    this.clip.pause();
    this.sound.pause();
  }

  private finish(): void {
    const then = this.done;
    if (!then) return;
    this.done = undefined;
    window.clearTimeout(this.timer);
    this.hush();
    this.root.classList.add("hidden");
    this.root.classList.remove("cheer-hold");
    then();
  }
}
