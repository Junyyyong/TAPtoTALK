package io.github.junyyyong.taptotalk;

import android.content.res.Configuration;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final int GAME_TEXT_ZOOM = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // BridgeActivity creates the WebView during super.onCreate().
        super.onCreate(savedInstanceState);
        applyGameTextZoom();
    }

    @Override
    public void onResume() {
        super.onResume();
        applyGameTextZoom();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyGameTextZoom();
    }

    private void applyGameTextZoom() {
        if (getBridge() == null) return;
        WebView webView = getBridge().getWebView();
        if (webView == null) return;
        // Only WebView text scaling changes. Keep OS density/magnification intact.
        webView.getSettings().setTextZoom(GAME_TEXT_ZOOM);
        // Reapply after the view hierarchy finishes a configuration/resume pass.
        webView.post(() -> webView.getSettings().setTextZoom(GAME_TEXT_ZOOM));
    }
}
